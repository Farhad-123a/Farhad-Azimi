 
package bmi;

 
public class BMI {
 
    public static void main(String[] args) {
            computeBmI person = new computeBmI("Karim", 20, 65, 1.76);
        String name = person.getName();
        int age = person.getAge();
        System.out.printf( "%.2f \n" ,person.getBMI());
        System.out.println("The " + name + " weight is  " + person.getStatus() + 
                " and he is " + age + " years old.");
    }
    
}
