package futuretuition;

import java.util.Scanner;

public class FutureTuition {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the tuition:");
        double tuition = input.nextDouble();
        double targetTuition = tuition * 2;
        double rate = 0.07;
        int year = 0;

        while (tuition < targetTuition) {
            tuition += tuition * rate;
            year++;

        }
        System.out.println("The tuition will double in " + year + " year");

    }
    
     
    }
