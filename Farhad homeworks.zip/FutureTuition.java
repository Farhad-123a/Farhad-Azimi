 
package futuretuition;
import java.util.Scanner;

public class FutureTuition {

     
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
      int tuition=10000;
      int year=1;
      while(tuition<=20000){
            tuition+=700;
             
             if (year==15)
                 System.out.println("The tuition will be doubled after "+year+" year");
                 year++;
       
                  
      }
            
            
         }
                 
             
             
         }
    }
}
    
