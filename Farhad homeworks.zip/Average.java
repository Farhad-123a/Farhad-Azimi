 
package average;
 import java.util.Scanner;
public class Average {

    
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
           int[] mylist = new int[100];
        int avr = 0;
        int sum = 0;
        for (int i = 0; i < mylist.length - 1; i++) {
            System.out.println("Enter the number ");
            mylist[i] = input.nextInt();
            sum += mylist[i];
        }
         avr = sum / mylist.length;
        System.out.println("sum of them " + sum);

        System.out.println("average is " + avr);
        for (int i = 0; i < mylist.length - 1; i++) {
            if(mylist[i]>avr){
                System.out.println(mylist[i]+" is above the average ");
            }else{
                System.out.println(mylist[i]+" is Below the average ");
            }
        }
    }
    
}
