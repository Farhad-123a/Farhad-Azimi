package loop;

import java.util.Scanner;

public class Loop {
-
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        while (true) {
            int ran1 = (int) (Math.random() * 100);
            System.out.println("enter your answer " + ran1);
            int answer = input.nextInt();

            if (ran1 == answer) {
                System.out.println("Your answer " + answer + " is true");

            } else if (ran1 <= 50) {
                System.out.println("The answer is less than 50 ");

            } else if (ran1 > 50) {
                System.out.println("The answer is bigger than 50");

            } else {
                System.out.println("Your answer " + answer + " is wrong");
            }
        }
    }

}
