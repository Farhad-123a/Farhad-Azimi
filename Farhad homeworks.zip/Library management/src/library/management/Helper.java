 
package library.management;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

 
public class Helper {
     public static Connection db_Connect(){
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Library", "root", "");   
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
        return con;
}
}
   

