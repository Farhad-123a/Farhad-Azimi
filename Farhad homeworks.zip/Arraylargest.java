 
package arraylargest;
import java.util.Scanner;
 
public class Arraylargest {

    
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
        System.out.println("Enter number of numbers ");
        int size =input.nextInt();
        double [] list = new double[size];
        int number=1;
        int sum=0;
        double large=list[0];
        int index=0;
        
        for (int i=0;i<list.length;i++){
            System.out.println("Enter the number");
            list[i]=input.nextDouble();
            sum+=list[i];
        }
        for (int i=0;i<list.length;i++){
            System.out.println(number+"."+"number; "+list[i]);
            number++;
          }
        for (int i=0;i<list.length;i++){
           if (list[i]> large){
             large=list[i];  
             index=i+1;
           }
          }
         
        System.out.println("Sum of numbers "+sum);
        System.out.println("The largest number "+large+ " and his location in "+ index);
        
    }
    
}
