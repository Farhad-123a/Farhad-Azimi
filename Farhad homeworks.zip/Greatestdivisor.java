package greatestdivisor;

import java.util.Scanner;

public class Greatestdivisor {

    public static void main(String[] args) {
                   Scanner input = new Scanner(System.in);
        System.out.println("Enter number 1:");
        int number1 = input.nextInt();
        System.out.println("Enter number 2:");
        int number2 = input.nextInt();
        
        int GCD=1;
        for(int i=1;i<=Math.min(number1, number2); i++){
            if(number1%i==0 && number2%i==0){
                GCD=i;
            }
            
            
        }System.out.println("The GCD is "+ GCD);
         }
        

}
