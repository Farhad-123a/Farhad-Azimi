package subquiz;

import java.util.Scanner;

public class Subquiz {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int count = 0;
        int num = 1;
        while (count != 5) {

            int que1 = (int) (Math.random() * 1000);
            int que2 = (int) (Math.random() * 100);
            System.out.println("Question " + num + ";" + " calculte " + que1 + "-" + que2 + "?");
            int sub = que1 - que2;

            System.out.println("Enter your answer ");
            int answer = input.nextInt();

            if (answer == sub) {
                System.out.println("your answer " + answer + " is true");

            } else {
                System.out.println("Your answer " + answer + " is false");

            }
            System.out.println("the correct answer " + sub);
            num++;
            count++;
        }
    }

}
