package angle.of.tringle;

import java.util.Scanner;

public class AngleOfTringle {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double x1, x2, x3, y1, y2, y3, A, B, C, a, b, c;
        System.out.println("enter the x1 point of tringle ");
        x1 = input.nextDouble();

        System.out.println("enter the x2 point of tringle ");
        x2 = input.nextDouble();

        System.out.println("enter the x3 point of tringle ");
        x3 = input.nextDouble();

        System.out.println("enter the y1 point of tringle ");
        y1 = input.nextDouble();

        System.out.println("enter the y2 point of tringle ");
        y2 = input.nextDouble();

        System.out.println("enter the y3 point of tringle ");
        y3 = input.nextDouble();

        a = Math.sqrt((x3 - x2) * (x3 - x2) + (y3 - y2) * (y3 - y2));
        b = Math.sqrt((x3 - x1) * (x3 - x1) + (y3 - y1) * (y3 - y1));
        c = Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));

        A = Math.acos((a * a - b * b - c * c) / (-2 * b * c));
        B = Math.acos((a * a - b * b - c * c) / (-2 * b * c));
        C = Math.acos((a * a - b * b - c * c) / (-2 * b * c));

        System.out.println("The angle A is:" + A);
        System.out.println("The angle B is:" + B);
        System.out.println("The angle C is:" + C);
    }

}
